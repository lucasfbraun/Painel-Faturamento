import type { Snapshot } from '../tipos';
import { formatarData, formatarHora } from '../utils/formatadores';
import { Marcador } from './Marcador';

interface Props {
  snapshot: Snapshot | null;
  atualizando: boolean;
  aoAtualizar: () => void;
  aoExportar: () => void;
  aoAlternarTema: () => void;
}

function descreverJanela(snapshot: Snapshot | null): string {
  if (!snapshot) return 'carregando…';
  const { janela, meta, pedidos } = snapshot;
  const ocultos = Math.max(0, meta.totalJanela - pedidos.length);
  const contagem =
    ocultos > 0 ? `${pedidos.length} pedidos em acompanhamento (${ocultos} faturados/cancelados ocultos)` : `${pedidos.length} pedidos`;
  return `Empresa ${meta.empresa} · janela ${formatarData(janela.inicio)} a ${formatarData(janela.fim)} (${janela.dias} dias) · ${contagem}`;
}

function descreverStatus(snapshot: Snapshot | null): string {
  if (!snapshot) return '—';
  if (!snapshot.ok) return 'falha na última consulta';
  return `atualizado ${formatarHora(snapshot.atualizadoEm)} · próximo ${formatarHora(snapshot.proximaAtualizacao)}`;
}

export function Cabecalho({ snapshot, atualizando, aoAtualizar, aoExportar, aoAlternarTema }: Props) {
  const corStatus = snapshot?.ok ? 'var(--status-bom)' : snapshot ? 'var(--status-critico)' : 'var(--texto-suave)';

  return (
    <header className="cabecalho">
      <div>
        <h1>Painel de Faturamento</h1>
        <p className="cabecalho__subtitulo">{descreverJanela(snapshot)}</p>
      </div>

      <div className="cabecalho__acoes">
        <span className="indicador-status">
          <Marcador cor={corStatus} />
          {descreverStatus(snapshot)}
        </span>
        <button type="button" onClick={aoAtualizar} disabled={atualizando}>
          {atualizando ? 'Atualizando…' : 'Atualizar agora'}
        </button>
        <button type="button" onClick={aoExportar}>
          CSV
        </button>
        <button type="button" onClick={aoAlternarTema} title="Alternar tema" aria-label="Alternar tema">
          ◐
        </button>
      </div>
    </header>
  );
}
