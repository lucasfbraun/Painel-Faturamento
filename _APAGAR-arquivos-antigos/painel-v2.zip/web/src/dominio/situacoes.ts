import { Situacao } from '../tipos';

/**
 * Cor de cada situação, em variáveis CSS definidas em `estilos/tokens.css`.
 *
 * A paleta foi validada para daltonismo (protanopia/deuteranopia/tritanopia) nos
 * temas claro e escuro. A cor nunca é o único sinal: todo selo carrega o rótulo
 * em texto, e a tabela existe como visão alternativa.
 */
export const VARIAVEL_COR_SITUACAO: Readonly<Record<number, string>> = {
  [Situacao.Digitado]: '--situacao-digitado',
  [Situacao.Listado]: '--situacao-listado',
  [Situacao.Liberado]: '--situacao-liberado',
  [Situacao.SelecionadoParcial]: '--situacao-sel-parcial',
  [Situacao.SelecionadoTotal]: '--situacao-sel-total',
  [Situacao.FaturadoParcial]: '--situacao-fat-parcial',
  [Situacao.FaturadoTotal]: '--situacao-fat-total',
  [Situacao.Transmitido]: '--situacao-transmitido',
  [Situacao.Bloqueado]: '--situacao-bloqueado',
  [Situacao.Cancelado]: '--situacao-cancelado',
};

export function corDaSituacao(situacao: number | null): string {
  const variavel = situacao === null ? undefined : VARIAVEL_COR_SITUACAO[situacao];
  return `var(${variavel ?? '--situacao-digitado'})`;
}

/** Destaque da linha na tabela: verde para faturável, vermelho para bloqueado. */
export type DestaqueLinha = 'liberado' | 'bloqueado' | 'cancelado' | 'neutro';

export function destaqueDaLinha(situacao: number | null): DestaqueLinha {
  switch (situacao) {
    case Situacao.Liberado:
      return 'liberado';
    case Situacao.Bloqueado:
      return 'bloqueado';
    case Situacao.Cancelado:
      return 'cancelado';
    default:
      return 'neutro';
  }
}
