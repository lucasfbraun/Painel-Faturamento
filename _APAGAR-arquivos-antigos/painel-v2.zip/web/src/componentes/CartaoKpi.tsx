import { formatarNumero } from '../utils/formatadores';
import { Marcador } from './Marcador';

export interface DadosKpi {
  rotulo: string;
  valor: number;
  dica: string;
  cor: string;
  destaque?: boolean;
}

export function CartaoKpi({ rotulo, valor, dica, cor, destaque = false }: DadosKpi) {
  return (
    <article className={`kpi${destaque ? ' kpi--destaque' : ''}`}>
      <h3 className="kpi__rotulo">
        <Marcador cor={cor} />
        {rotulo}
      </h3>
      <p className="kpi__valor">{formatarNumero(valor)}</p>
      <p className="kpi__dica">{dica}</p>
    </article>
  );
}
