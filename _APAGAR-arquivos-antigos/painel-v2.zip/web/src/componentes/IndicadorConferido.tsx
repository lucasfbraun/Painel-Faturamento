import type { Conferido } from '../tipos';

interface Props {
  valor: Conferido;
}

export function IndicadorConferido({ valor }: Props) {
  const conferido = valor === 'Sim';
  return (
    <span className={`conferido ${conferido ? 'conferido--sim' : 'conferido--nao'}`}>
      <span aria-hidden="true">{conferido ? '✓' : '○'}</span>
      {valor}
    </span>
  );
}
